export const Checkout = () => 
{
        return <h1 className="checkout">You have successfully checkout</h1>
}