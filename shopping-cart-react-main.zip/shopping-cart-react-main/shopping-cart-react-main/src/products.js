import product1 from "./assets/products/vot-cau-long-lining-3d-calibar-001.webp";
import product2 from "./assets/products/vot-cau-long-lining-axforce-60.webp";
import product3 from "./assets/products/vot-cau-long-lining-axforce-cannon.webp";
import product4 from "./assets/products/ao-cau-long-victor-359-nam.webp";
import product5 from "./assets/products/ao-cau-long-yonex-vm1012-nu.webp";
import product6 from "./assets/products/ao-cau-long-yonex-vm1017-nu.webp";
import product7 from "./assets/products/giay-cau-long-yonex-atlas.webp";
import product8 from "./assets/products/giay-cau-long-yonex-eclipsion-x3-xanh-navy.jpg";
import product9 from "./assets/products/giay-cau-long-yonex-shb-65z3.webp";

export const PRODUCTS = [
  {
    id: 1,
    productName: "Vợt cầu lông lining 3D calibar 001",
    price: 1500000,
    productImage: product1,
  },
  {
    id: 2,
    productName: "Vợt cầu lông axforce 60",
    price: 3900000,
    productImage: product2,
  },
  {
    id: 3,
    productName: "Vợt cầu lông axforce cannon",
    price: 1100000,
    productImage: product3,
  },
  {
    id: 4,
    productName: "Áo cầu lông nam victor 359",
    price: 160000,
    productImage: product4,
  },
  {
    id: 5,
    productName: "Áo cầu lông nữ yonex vm1012",
    price: 130000,
    productImage: product5,
  },
  {
    id: 6,
    productName: "Áo cầu lông nữ yonex vm1017",
    price: 160000,
    productImage: product6,
  },
  {
    id: 7,
    productName: "Giày cầu lông yonex atlas",
    price: 800000,
    productImage: product7,
  },
  {
    id: 8,
    productName: "Giày cầu lông yonex eclipsion",
    price: 1200000,
    productImage: product8,
  },
  {
    id: 9,
    productName: "Giày cầu lông yonex shb",
    price: 2300000,
    productImage: product9,
  },
];
