import { useState } from "react";
import LoginForm from "../LoginForm/LoginForm";
import { Shop } from "../../pages/shop/shop";
import { useNavigate } from 'react-router-dom';


function LoginContext() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();
  if(isLoggedIn)
  {
    navigate("/");
    return <Shop />

  }
  return <LoginForm setIsLoggedIn={setIsLoggedIn} />
}

export default LoginContext;